package info.androidhive.speechtotext;

/**
 * Created by Vipul Jha on 25-04-2018.
 */

class AppCompatActivity {
}
